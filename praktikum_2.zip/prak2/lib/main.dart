import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Oba Ilo Takbir|| 2200016059"),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Container(
            padding: EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(30),
                  color: Color.fromARGB(244, 232, 103, 172),
                  child: Text(
                    'KOREA',
                  ),
                ), //text
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("HAI"),
                    Text("YOGI"),
                    Text("YADI"),
                    Text("BUDI"),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("HAI"),
                    Text("YOGI"),
                    Text("YADI"),
                    Text("BUDI"),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
